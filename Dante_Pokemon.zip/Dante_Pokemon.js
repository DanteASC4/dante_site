//Defining the class pokemon
class pokemon {
  //Setting the parameters
  constructor(name, type, hp, def, atk, legend){
    this.name = name;
    this.type = type;
    this.hp = hp;
    this.def = def;
    this.atk = atk;
    this.legend = legend;
    //Function to check if it's a valid pokemon by seeing if it's anything other than it should be, if it is anything other than the thing it should be it'll throw a type error, if it's good it'll say all clear.
    this.check = function(name, type, hp, def, atk, legend ){

      if(typeof this.name != 'string' ){
        throw new TypeError("thats not a valid name")
      }
      if(typeof this.type != 'string'){
        throw new TypeError("thats not a valid type")
      }
      if(typeof this.hp != 'number'){
        throw new TypeError("thats not a valid hp stat")
      }
      if(typeof this.def != 'number'){
        throw new TypeError("thats not a valid defense stat")
      }
      if(typeof this.atk != 'number'){
        throw new TypeError("thats not a valid attack stat")
      }
      if(typeof this.legend != 'boolean'){
        throw new TypeError("thats not a valid legend identifier")
      }
      else{
        console.log('that\'s a valid pokemon You\'re good to go')
      }
    }
    //I invoke the check function everytime a pokemon is constructed
    this.check()
    //Attack function, works like it should, takes a target pokemon as a parameter, when called by another pokemon
    this.attack = function(target){
      if(target instanceof pokemon){
          this.atk -= target.def
          target.hp -= this.atk
          console.log(target.hp)
        }
        else {
          console.log('You\'re not attacking a pokemon, don\'t do that!!')
        }
      }
    //Checks if pokemon is still alive,
    this.aliveCheck = function(poke){
      if(poke instanceof pokemon){
        if(poke.hp > 0){
          console.log("he's alive!")
        }
        else{
          console.log("Take that pokemon to Nurse Joy at the pokemon center asap!")
        }
      }
      else{
          console.log('Yoy cannot check a non pokemon sorry!')
        }
      }
      //If it doesn't exist, make it!
      if(!pokemon.all){
        pokemon.all = []
      }
      //Push all instances of pokemon creations to the empty array!
      pokemon.all.push(this)

    }
  }
